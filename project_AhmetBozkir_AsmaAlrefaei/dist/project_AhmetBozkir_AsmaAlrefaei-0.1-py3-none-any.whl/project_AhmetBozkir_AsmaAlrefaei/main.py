def hello():
    print("hello Asma")